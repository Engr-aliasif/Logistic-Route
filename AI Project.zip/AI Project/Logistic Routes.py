from queue import PriorityQueue
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd

# Function to perform Uniform Cost Search (UCS)
def uniform_cost_search(start, goal):
    pq = PriorityQueue()
    pq.put((0, start, [start]))  # Include the path in the priority queue
    visited = set()

    while not pq.empty():
        current_cost, current_node, current_path = pq.get()

        if current_node == goal:
            return current_path, current_cost  # Return the path and cost

        if current_node not in visited:
            visited.add(current_node)

            for neighbor, edge_cost in get_neighbors(current_node):
                new_cost = current_cost + edge_cost
                new_path = current_path + [neighbor]

                pq.put((new_cost, neighbor, new_path))

    return None, None  # Return None if no path is found

# Function to get neighbors of a node
def get_neighbors(node):
    return [(neighbor, graph[node][neighbor]) for neighbor in graph[node]]

# Read the graph from an Excel file
def read_graph(filename, sheet_name='Sheet1'):
    try:
        df = pd.read_excel(filename, sheet_name=sheet_name)
    except FileNotFoundError:
        raise FileNotFoundError(f"File not found at path: {filename}")
    except Exception as e:
        raise e

    graph = {}

    for index, row in df.iterrows():
        node1, node2, distance = row['Node1'], row['Node2'], row['Distance']

        if node1 not in graph:
            graph[node1] = {}
        if node2 not in graph:
            graph[node2] = {}

        graph[node1][node2] = distance
        graph[node2][node1] = distance

    return graph

# Main code

# Specify the Excel file path
excel_filename = r'C:\Users\ali4s\OneDrive\Desktop\Ai Project\List\Pakmap.xlsx'

# Read the graph from the Excel file
graph = read_graph(excel_filename)

# Displaying the graph matrix
#print("Graph (Node 1 to Node 2 with Distance):")
#for node1 in graph:
   ## for node2 in graph[node1]:
     #  print(f"{node1} to {node2} with Distance {graph[node1][node2]}")

# Get user input for start node
while True:
    start_node = input("Current Location: ")
    if start_node in graph:
        break
    else:
        print(f"Node '{start_node}' not found in the graph. Please enter a valid node.")

# Get user input for goal node
while True:
    goal_node = input("Where you want to GO! ")
    if goal_node in graph:
        break
    else:
        print(f"Your Place '{goal_node}' not found in our list. Please enter a valid Place Name.")

# Run UCS and display the result
min_cost_path, min_cost = uniform_cost_search(start_node, goal_node)

if min_cost_path:
    optimal_path_values = [graph[node].get('Value', node) for node in min_cost_path]
    print(f"Best path from {start_node} to {goal_node} : {optimal_path_values}")
    print(f"Total Distance: {min_cost}")
else:
    print(f"No path found from {start_node} to {goal_node}.")

# Visualize the graph and the minimum cost path with fixed node positions
G = nx.Graph()
for node1 in graph:
    for node2 in graph[node1]:
        G.add_edge(f'{node1}', f'{node2}', weight=graph[node1][node2])

pos = nx.spring_layout(G, seed=42)  # Seed for consistent layout
nx.draw(G, pos, with_labels=True, font_weight='bold', font_color='Black' ,node_size=500, node_color='white', font_size=7)
labels = nx.get_edge_attributes(G, 'weight')
nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)

if min_cost_path:
    min_cost_edges = [(f'{min_cost_path[i]}', f'{min_cost_path[i + 1]}') for i in range(len(min_cost_path) - 1)]
    nx.draw_networkx_edges(G, pos, edgelist=min_cost_edges, edge_color='red', width=2)

plt.title(f"Distance from : {node1} to {node2} : with Best Path\nOptimal Path: {optimal_path_values}\nTotal Distance: {min_cost}")
plt.show()
