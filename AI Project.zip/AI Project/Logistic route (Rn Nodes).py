import heapq
import networkx as nx
import matplotlib.pyplot as plt
import string
import random

class Graph:
    def __init__(self):
        self.graph = nx.Graph()

    def add_node(self, value):
        self.graph.add_node(value)

    def add_edge(self, from_node, to_node, cost):
        self.graph.add_edge(from_node, to_node, weight=cost)

def uniform_cost_search(graph, start, goal):
    priority_queue = [(0, start, [])]  # (cost, node, path)
    visited = set()

    while priority_queue:
        cost, current_node, path = heapq.heappop(priority_queue)

        if current_node not in visited:
            visited.add(current_node)
            path = path + [current_node]

            if current_node == goal:
                return path, cost

            for neighbor in graph.graph.neighbors(current_node):
                if neighbor not in visited:
                    edge_cost = graph.graph[current_node][neighbor]['weight']
                    heapq.heappush(priority_queue, (cost + edge_cost, neighbor, path))

    return None, None  # No path found

# Function to highlight the path edges in red
def highlight_path_edges(graph, path):
    path_edges = [(path[i], path[i + 1]) for i in range(len(path) - 1)]
    edge_colors = ['red' if edge in path_edges else 'gray' for edge in graph.graph.edges()]
    return edge_colors

# Example Usage:
logistics_graph = Graph()

# Input number of nodes
num_nodes = int(input("Enter the number of nodes: "))

# Generate node values as letters (A, B, C, ...)
node_values = [letter for letter in string.ascii_uppercase[:num_nodes]]

# Add nodes to the graph
for value in node_values:
    logistics_graph.add_node(value)

# Input number of edges
num_edges = int(input("Enter the number of edges: "))

# Generate random edges with random weights
for _ in range(num_edges):
    from_node = random.choice(node_values)
    to_node = random.choice(node_values)
    while from_node == to_node:  # Ensure the source and destination are different
        to_node = random.choice(node_values)
    edge_cost = round(random.uniform(1, 10), 2)  # Round to 2 decimal places
    logistics_graph.add_edge(from_node, to_node, edge_cost)

# Visualization
pos = nx.spring_layout(logistics_graph.graph)
nx.draw(logistics_graph.graph, pos, with_labels=True, node_size=700, node_color='skyblue', font_size=10)

# Draw edges
edge_labels = {(i, j): f"{w:.2f}" for i, j, w in logistics_graph.graph.edges(data='weight')}
nx.draw_networkx_edge_labels(logistics_graph.graph, pos, edge_labels=edge_labels)

plt.show()

# Input start and goal locations
start_location = input("Enter start location (A, B, C, ...): ").upper()
goal_location = input("Enter goal location (A, B, C, ...): ").upper()

optimized_path, total_cost = uniform_cost_search(logistics_graph, start_location, goal_location)

if optimized_path:
    print(f"Optimized Path: {optimized_path}")
    print(f"Total Cost: {total_cost:.2f}")

     # Print edge values along the optimal path
    print("Edge values along the optimal path:")
    for i in range(len(optimized_path) - 1):
        from_node = optimized_path[i]
        to_node = optimized_path[i + 1]
        edge_cost = logistics_graph.graph[from_node][to_node]['weight']
        print(f"Edge ({from_node}, {to_node}): {edge_cost:.2f}")
    # Highlight path edges in red
    edge_colors = highlight_path_edges(logistics_graph, optimized_path)

    # Visualization with highlighted path
    nx.draw(logistics_graph.graph, pos, with_labels=True, node_size=700, node_color='skyblue', font_size=10, edge_color=edge_colors)
    nx.draw_networkx_edge_labels(logistics_graph.graph, pos, edge_labels=edge_labels)
    plt.show()
else:
    print("No path found.")
