from flask import Flask, render_template, request, jsonify
from queue import PriorityQueue
import networkx as nx
import pandas as pd

app = Flask(__name__)

# Function to perform Uniform Cost Search (UCS)
def uniform_cost_search(start, goal, graph):
    pq = PriorityQueue()
    pq.put((0, start, [start]))  # Include the path in the priority queue
    visited = set()

    while not pq.empty():
        current_cost, current_node, current_path = pq.get()

        if current_node == goal:
            return current_path, current_cost  # Return the path and cost

        if current_node not in visited:
            visited.add(current_node)

            for neighbor, edge_cost in get_neighbors(current_node, graph):
                new_cost = current_cost + edge_cost
                new_path = current_path + [neighbor]

                pq.put((new_cost, neighbor, new_path))

    return None, None  # Return None if no path is found

# Function to get neighbors of a node
def get_neighbors(node, graph):
    return [(neighbor, graph[node][neighbor]) for neighbor in graph[node]]

# Read the graph from an Excel file
def read_graph(filename, sheet_name='Sheet1'):
    try:
        df = pd.read_excel(filename, sheet_name=sheet_name)
    except FileNotFoundError:
        raise FileNotFoundError(f"File not found at path: {filename}")
    except Exception as e:
        raise e

    graph = {}

    for index, row in df.iterrows():
        node1, node2, distance = row['Node1'], row['Node2'], row['Distance']

        if node1 not in graph:
            graph[node1] = {}
        if node2 not in graph:
            graph[node2] = {}

        graph[node1][node2] = distance
        graph[node2][node1] = distance

    return graph

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate_shortest_path', methods=['POST'])
def calculate_shortest_path():
    start_location = request.form['start_location']
    destination = request.form['destination']

    graph = read_graph(r'C:\Users\ali4s\OneDrive\Desktop\AI Project\Version 0.1\Pakmap.xlsx')  # Adjust the filename as per your Excel file

    if start_location not in graph or destination not in graph:
        return jsonify(error='Invalid locations provided'), 400

    min_cost_path, min_cost = uniform_cost_search(start_location, destination, graph)

    if min_cost_path:
        optimal_path_values = [graph[node].get('Value', node) for node in min_cost_path]
        return jsonify(path=optimal_path_values, distance=min_cost)
    else:
        return jsonify(error='No path found'), 404

if __name__ == '__main__':
    app.run(debug=True)
